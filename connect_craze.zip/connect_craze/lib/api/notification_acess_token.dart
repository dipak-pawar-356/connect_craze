import 'dart:developer';

//import 'package:googleapis_auth/auth.dart';
import 'package:googleapis_auth/auth_io.dart';

//import 'package:googleapis_auth/auth_io.dart';

class NotificationAccessToken {
  static String? _token;

  //to generate token only once for an app run
  static Future<String?> get getToken async =>
      _token ?? await _getAccessToken();

  // to get admin bearer token
  static Future<String?> _getAccessToken() async {
    try {
      const fMessagingScope =
          'https://www.googleapis.com/auth/firebase.messaging';

      final client = await clientViaServiceAccount(
        // To get Admin Json File: Go to Firebase > Project Settings > Service Accounts
        // > Click on 'Generate new private key' Btn & Json file will be downloaded

        // Paste Your Generated Json File Content
        ServiceAccountCredentials.fromJson({
          "type": "service_account",
          "project_id": "connect-craze",
          "private_key_id": "e9f4b9975a44ffb46dabf298fb522a10c2913869",
          "private_key":
              "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC/w+V9wR3ka99l\nTyJojxFjjbP0HddB0P8Ne+c7L83V2COHF202EGAaO52z/rnxYojK+/X/YkpwuG89\nWdpRhmXOjQfEoVVKIA5YdR8td0qQNVyS9FAxFlQ+ElsrrKIZd4sktEqPzjbHhGls\nDAQ9tczDchg9qEpC27q+w2zvB2VXQj6L84q7cSFmkBtE8qYcAS3vhXD15W2W04Gc\nH+qBcfAGXfSoerOho7P0vYufzfkVhDR2hoPRFhRIMLtQ1hfkS+lAL00D3muedcBM\nOihHJP1BNLXgDYKqUOpP3LViCjXpmpxzDaFYxiBUx841kZc6RT31Sy02EosQ9SPz\nuR5m9nclAgMBAAECggEAB8UyXGvek1w+oPGGfKbT05oEKtX2grN4BKeBLJAIxTIJ\n0H/FwsBoahYbBm/bWd++MlfOzwjmm/yRMox2EPWDIXRr/LVbCh+hGfr9WixT0GLL\njAw++QCe+PJP91KHSysub2/BxLCpRHp5HH7V9I7Hcjtb8zJv3eRe6jtrdtNwvj4X\n0NcmKYzaBvV1bZL/uqQJ1qUyhIGO6FbMxxPV1MpSvOplbrPsHFqUx2gLY17Yz9x9\n2s/0GtC/rCpnEC8vAuMR8wr8TGARp1HOav+3F5skCadceyQ/Y6i4R/zBwtpRNyo1\nmAA4HkHG0CAkd3ufp4VvmsZlowhxd6NLocot2IqAYQKBgQDY5RG/oOauWLxhkMwU\noJ4yIfPRq1dta6awJHM5odSVgz5YNa2dZUcE6HkeKj//Xm6NbfG+6ayIdJLjoOeE\nUzGBuUtRzKE5QgFC6YLxvgNLm276b0nIAzJLlvzRjmdB51bzDC7iI91WGyTvHi+n\n5YlDwgrcia1H1kiYHyGF03oZIQKBgQDiVvQq1K/Jvg0RBrOpaPA/gy6D2aCF4Nk3\nh8NG66je8Mb+b6wj5LbYZVhea0eTKX05oGxE4qAnecg1V8mFHTrZikfQ4T35jD2Q\n5tOQ0GEKS18jUWvrIfaw+GjMz1CjfuebU4Bwn0ZcScmu/7KSS0X72P1wpGfgBN7y\nsVKN6r1JhQKBgGmdujPPPSV+7lSwNsCAqigNYnYh8lPFDQlO5pEU3bjkjPJVSTKQ\nw7F/JqNqvXkz2a+i7wohLbPQ2Eph6vsDq+LYgPXXKFcCbizQGsRu25nwmWz3zjzI\nWbB3WKsOpfdwmGWH9DiIcFpio2yRDXG7k0jcb3+Ox0No9DanSiKppRYhAoGBANHo\nSHtsUjbsDZwrtfU4AA827q2S5/8hHvIT83NTXIKdlD8le+Sx2SzpGEJAhdmiEaOe\n9qoP7u2NULK/3oGYMRrM1nuOWPaVLAe1OqJDzqtIaUwM1+Px1KIdTrwazDNEnzD7\nCNPpsswmFmg4dPid3KKLg8eygS9N9SHod6Jr/+4tAoGAN/hfSih8Y+D60wvN4rXN\nr22OZqKjj5/vZWXjzXgJ1zB9MV1TMq3vinBHfOPz6Vcg529oSZ7+QmVfYcdU2Qaa\nE5zGG0nEl/RmtW1uZUDZ1kdVmfjJG/rD+GGYSUU/YiC8JGN0/MAnrpTm5vzIRDYY\nFZKcMhRooKy6tw+zC/mGJ2c=\n-----END PRIVATE KEY-----\n",
          "client_email":
              "firebase-adminsdk-wrrtx@connect-craze.iam.gserviceaccount.com",
          "client_id": "105005828174725390506",
          "auth_uri": "https://accounts.google.com/o/oauth2/auth",
          "token_uri": "https://oauth2.googleapis.com/token",
          "auth_provider_x509_cert_url":
              "https://www.googleapis.com/oauth2/v1/certs",
          "client_x509_cert_url":
              "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-wrrtx%40connect-craze.iam.gserviceaccount.com",
          "universe_domain": "googleapis.com"
        }),
        [fMessagingScope],
      );

      _token = client.credentials.accessToken.data;

      return _token;
    } catch (e) {
      log('$e');
      return null;
    }
  }
}
