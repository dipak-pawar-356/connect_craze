class Message {
  late final String msg;
  late final String toId;
  late final String read;
  late final Type type;
  late final String sent;
  late final String fromId;

  // Constructor using required keyword for all fields
  Message({
    required this.msg,
    required this.toId,
    required this.read,
    required this.type,
    required this.sent,
    required this.fromId,
  });

  // Factory constructor for creating a new Message instance from a map
  Message.fromJson(Map<String, dynamic> json) {
    msg = json['msg'].toString();
    toId = json['toId'].toString();
    read = json['read'].toString();
    type = json['type'].toString() == Type.image.name ? Type.image : Type.text;
    sent = json['sent'].toString();
    fromId = json['fromId'].toString();
  }

  // Method to convert a Message instance into a Map with a data[] structure
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{}; // Creating a map
    data['msg'] = msg;
    data['toId'] = toId;
    data['read'] = read;
    data['type'] = type.name;
    data['sent'] = sent;
    data['fromId'] = fromId;
    return data;
  }
}

enum Type { text, image }

// ai message
class AiMessage {
  String msg;
  final MessageType msgType;

  AiMessage({required this.msg, required this.msgType});
}

enum MessageType { user, bot }
