import 'dart:developer';

import 'package:connect_craze/api/apis.dart';
//import 'package:connect_craze/main.dart';
import 'package:connect_craze/screens/auth/login_screen.dart';
import 'package:connect_craze/screens/home_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// //Splash Screen
// class SplashScreen extends StatefulWidget {
//   const SplashScreen({super.key});

//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen> {
//   bool _isAnimate = false;
//   //late Size mq;

//   @override
//   void initState() {
//     super.initState();
//     Future.delayed(Duration(seconds: 2), () {
//       //navigate to full screen
//       SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
//       SystemChrome.setSystemUIOverlayStyle(
//           const SystemUiOverlayStyle(statusBarColor: Colors.transparent));
//       Navigator.pushReplacement(
//           context, MaterialPageRoute(builder: (_) => const LoginScreen()));
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     mq = MediaQuery.of(context).size;

//     return Scaffold(
//       //app bar
//       appBar: AppBar(
//         title: Text('Welcome to Connect Craze'),
//         automaticallyImplyLeading: false,
//       ),
//       //body
//       body: Stack(
//         children: [
//           //app logo
//           Positioned(
//             top: mq.height * .15,
//             right: mq.width * .25,
//             width: mq.width * .5,
//             child: Image.asset('assets/images/mobile-chat.png'),
//           ),
//           //google login button
//           Positioned(
//             bottom: mq.height * .15,
//             width: mq.width,
//             child: Text(
//               'MADE IN INDIA WITH ❤️',
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                   fontSize: 16, color: Colors.black87, letterSpacing: .5),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  //bool _isAnimate = false;
  late Size mq;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      //exit full-screen
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
          systemNavigationBarColor: Colors.white,
          statusBarColor: Colors.white));

      if (APIs.auth.currentUser != null) {
        log('\nUser: ${APIs.auth.currentUser}');

        //navigate to home screen
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => const HomeScreen()));
      } else {
        //navigate to login screen
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => const LoginScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    //initializing media query (for getting device screen size)
    mq = MediaQuery.of(context).size; // Initialize locally

    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to Connect Craze'),
        automaticallyImplyLeading: false,
      ),
      body: Stack(
        children: [
          Positioned(
            top: mq.height * .15,
            right: mq.width * .25,
            width: mq.width * .5,
            child: Image.asset('assets/images/mobile-chat.png'),
          ),
          Positioned(
            bottom: mq.height * .15,
            width: mq.width,
            child: Text(
              'MADE IN INDIA WITH ❤️',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 16, color: Colors.black87, letterSpacing: .5),
            ),
          ),
        ],
      ),
    );
  }
}
